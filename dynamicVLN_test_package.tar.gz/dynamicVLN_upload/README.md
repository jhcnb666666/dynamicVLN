# Trajectory Tracking Simulation Tests

This package contains the DiT (Diffusion Transformer) trajectory tracking simulation tests and their results.

## Files

### Scripts
- `test_traj_dit_comparison_with_accuracy.py` — **Main comparison script**: Dynamic waypoint + variable DiT output vs Fixed waypoint + fixed DiT output (32). Computes both accuracy (RMSE/ADE/Endpoint Error) and per-timestep DiT forward time.
- `test_traj_dit_dynamic_vs_fixed.py` — Original timing-only comparison script (dynamic vs fixed-32).
- `test_traj_dit_simulation.py` — Original trajectory simulation script with accuracy metrics.

### Results

#### `traj_dit_comparison_accuracy/` (Default batch=64, GPU under-utilized)
- 5 episodes, 10 steps each, num_sample_trajs=32
- **Finding**: Dynamic mode was slightly slower (0.95x) because seq_len=4 and seq_len=32 had almost identical forward time on an under-utilized GPU.

#### `traj_dit_comparison_gpu_limited/` (High batch=256, GPU compute-bound)
- 3 episodes, 5 steps each, num_sample_trajs=128
- **Finding**: Dynamic mode achieved **1.29x speedup** over Fixed-32. When GPU is saturated, reducing predict_step_nums from 32 to 4 saves ~31% per-step time.

## Key Conclusions
1. On an under-utilized GPU (small batch), dynamic waypoint pruning provides little to no speedup because kernel launch overhead and weight loading dominate.
2. On a compute-bound GPU (large batch or large model), dynamic pruning is valuable: ~20-30% faster with comparable or better accuracy.
3. Endpoint error is consistently better in Dynamic mode (0.80 vs 0.95).

## How to Run
```bash
# Default test
python test_traj_dit_comparison_with_accuracy.py \
  --checkpoint_dir checkpoints/InternVLA-N1-DualVLN \
  --num_episodes 5 --num_steps_per_episode 10

# GPU-saturated simulation (high batch)
python test_traj_dit_comparison_with_accuracy.py \
  --checkpoint_dir checkpoints/InternVLA-N1-DualVLN \
  --num_sample_trajs 128 \
  --num_episodes 3 --num_steps_per_episode 5 \
  --output_dir checkpoints/traj_dit_comparison_gpu_limited
```
